// Import required data
const setData = require("../data/setData");
const themeData = require("../data/themeData");

let sets = []; // This will hold the processed Lego sets

// Function to initialize and populate the 'sets' array
function initialize() {
  return new Promise((resolve, reject) => {
    if (!setData || !themeData) {
      reject("Data loading failed");
    }

    sets = setData.map((set) => {
      const theme = themeData.find(
        (theme) => theme.id.toString() === set.theme_id.toString()
      );
      return { ...set, theme: theme ? theme.name : "Unknown" };
    });

    resolve();
  });
}

// Function to get all sets
function getAllSets() {
  return new Promise((resolve, reject) => {
    if (sets.length > 0) {
      resolve(sets);
    } else {
      reject("No sets found");
    }
  });
}

// Function to find a set by its number
function getSetByNum(setNum) {
  return new Promise((resolve, reject) => {
    const set = sets.find((set) => set.set_num === setNum);
    if (set) {
      resolve(set);
    } else {
      reject(`Set number ${setNum} not found`);
    }
  });
}

// Function to find sets by theme (partial match and case insensitive)
function getSetsByTheme(theme) {
  return new Promise((resolve, reject) => {
    const filteredSets = sets.filter((set) =>
      set.theme.toLowerCase().includes(theme.toLowerCase())
    );
    if (filteredSets.length > 0) {
      resolve(filteredSets);
    } else {
      reject(`No sets found with theme containing "${theme}"`);
    }
  });
}

// Exporting functions
module.exports = { initialize, getAllSets, getSetByNum, getSetsByTheme };
