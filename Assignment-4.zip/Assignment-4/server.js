/********************************************************************************
 *WEB322 – Assignment 04
 *
 *  I declare that this assignment is my own work in accordance with Seneca's
 *  Academic Integrity Policy:
 *
 *  https://www.senecacollege.ca/about/policies/academic-integrity-policy.html
 *
 *  Name: Heet Patel Student ID: 167461219 Date: Mar 4 2024
 *
 ********************************************************************************/

// Import the legoSets module
const legoData = require("./modules/legoSets");
const express = require("express");
const path = require("path");
const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.join(__dirname, "public")));

const HTTP_PORT = process.env.PORT || 8080;

// Root
app.get("/", (req, res) => {
  res.render("home");
});

app.get("/about", (req, res) => {
  res.render("about");
});

app.get("/lego/sets", async (req, res) => {
  try {
    if (req.query.theme) {
      const legoSets = await legoData.getSetsByTheme(req.query.theme);
      res.render("sets", { sets: legoSets, theme: req.query.theme });
    } else {
      const legoSets = await legoData.getAllSets();
      res.render("sets", { sets: legoSets, theme: "" });
    }
  } catch (err) {
    res.status(404).render("404", { message: "Error retrieving Lego sets" });
  }
});

app.get("/lego/sets/:set_num", async (req, res) => {
  try {
    const legoSets = await legoData.getSetByNum(req.params.set_num);
    if (legoSets) {
      res.render("set", { set: legoSets, theme: "" });
    } else {
      res
        .status(404)
        .render("404", {
          message: "I'm sorry, we're unable to find what you're looking for",
        });
    }
  } catch (err) {
    res
      .status(404)
      .render("404", {
        message: "I'm sorry, we're unable to find what you're looking for",
      });
  }
});

//  LEGO sets by theme
app.get("/lego/sets/theme-demo", async (req, res) => {
  try {
    let sets = await legoData.getSetsByTheme("tech");
    res.json(sets);
  } catch (err) {
    res
      .status(404)
      .render("404", { message: "Sets with the specified theme not found." });
  }
});

// Catch-all handler for any other route not defined.
app.use((req, res) => {
  res
    .status(404)
    .render("404", {
      message: "I'm sorry, we're unable to find what you're looking for",
    });
});

legoData
  .initialize()
  .then(() => {
    app.listen(HTTP_PORT, () => {
      console.log(`Server listening on: ${HTTP_PORT}`);
    });
  })
  .catch((err) => {
    console.error("Failed to initialize data:", err);
  });
